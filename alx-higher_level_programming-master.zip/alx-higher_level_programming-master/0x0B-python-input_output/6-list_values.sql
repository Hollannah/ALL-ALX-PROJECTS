-- list all rows of the frist_table
SELECT * FROM `first_table`;
