-- create a table called first_table with id and name
CREATE TABLE IF NOT EXISTS `first_table` (`id` INT, `name` VARCHAR(256));
