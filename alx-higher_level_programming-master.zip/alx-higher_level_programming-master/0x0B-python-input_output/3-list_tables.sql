-- lists all the tables of a database in mysql
SHOW TABLES;
