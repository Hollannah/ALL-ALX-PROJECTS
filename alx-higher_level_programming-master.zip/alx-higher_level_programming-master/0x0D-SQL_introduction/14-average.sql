-- Computes the average score of all records in the table second_table in my MySQL server.
SELECT AVG(`score`) AS `average`
FROM `second_table`;
