-- script that lists all databases of MySQL server
SHOW DATABASES;
