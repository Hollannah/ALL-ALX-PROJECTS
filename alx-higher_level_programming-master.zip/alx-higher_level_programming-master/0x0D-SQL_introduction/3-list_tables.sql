-- Lists all tables of a database.
SHOW TABLES;
