-- script that creates the database hbtn_0c_0
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;
