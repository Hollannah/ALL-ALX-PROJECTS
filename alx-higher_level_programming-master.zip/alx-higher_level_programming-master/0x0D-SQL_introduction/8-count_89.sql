-- Displays the number of records with id = 89 in the table first_table.
SELECT COUNT(*)
FROM `first_table`
WHERE `id` = 89;
