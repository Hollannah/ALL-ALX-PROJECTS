#!/usr/bin/python3
for i in range(97, 123):
    tableAsciiToAlphabet = chr(i)
    asciiToAlpha = "" + tableAsciiToAlphabet
    print("{}".format(asciiToAlpha), end='')
