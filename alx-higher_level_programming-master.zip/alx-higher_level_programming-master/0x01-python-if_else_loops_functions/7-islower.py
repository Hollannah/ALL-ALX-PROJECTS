#!/usr/bin/python3
def islower(c):
    number = ord(c)
    if number in range(97, 123):
        return True
    return False
