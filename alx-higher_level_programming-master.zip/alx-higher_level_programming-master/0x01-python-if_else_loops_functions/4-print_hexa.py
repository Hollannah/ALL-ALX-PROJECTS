#!/usr/bin/python3
# print 0 to 98 in both hexadecimal and decimal
for hexDec in range(0, 99):
    print("{} = {}".format(hexDec, hex(hexDec)))
