#!/usr/bin/python3
"""
Defines an empty class Rectangle
"""


class Rectangle:
    """Empty representation of a rectangle"""
    pass
