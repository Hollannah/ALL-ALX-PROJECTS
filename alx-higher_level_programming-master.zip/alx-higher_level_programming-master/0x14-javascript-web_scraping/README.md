# 0x14. Javascript - Web scraping
## Description
What you should learn from this project: b''

* b'Why Javascript programming is amazing (don\xe2\x80\x99t forget to tweet today, with the hashtag #javascriptisamazing :))'
* b'How to manipulate JSON data'
* b'How to use request and fetch API'
* b'How to read and write a file using fs module'
### 0. Readme
b'Write a script that reads and prints the content of a file.'
### 1. Write me
* b'Write a script that writes a string to a file.'
### 2. Status code
* b'Write a script that display the status code of a GET request.'
### 3. Star wars movie title
* b'Write a script that prints the title of a Star Wars movie where the episode number matches a given integer.'
### 4. Star wars Wedge Antilles
* b'Write a script that prints the number of movies where the character \xe2\x80\x9cWedge Antilles\xe2\x80\x9d is present.'
### 5. Loripsum
* b'Write a script that gets the contents of a webpage and stores it in a file.'
### 6. How many completed?
* b'Write a script that computes the number of tasks completed by user id.'
### 7. Who was playing in this movie?
* b'Write a script that prints all characters of a Star Wars movie:'
### 8. Right order
* b'Write a script that prints all characters of a Star Wars movie:'
### 9. Twitter Auth
* b'Write a Javascript script that takes in 3 strings and sends a search request to the Twitter API'
## Author
Olaide Olajide Hannah - Hollannah
