#!/usr/bin/node
// Empty definition of a rectangle
module.exports = class Rectangle {};
