#include <stdio.h>
/**
 * main - print a line of code using puts
 *
 * Return: 0
*/
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
