It ain't what they call you, it's what you answer to
1. Silence is argument carried out by other means
2. The best argument against democracy is a five-minute conversation with the average voter
3. Neither irony nor sarcasm is argument
4. To infinity and beyond
5. Minimal Number of Coins for Change

