int_putchar(char c);
int_check_num(char *str);
