coding day today will be great
