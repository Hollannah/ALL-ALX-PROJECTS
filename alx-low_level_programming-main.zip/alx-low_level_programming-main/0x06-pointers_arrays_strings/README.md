README for more pointers arrays and strings
