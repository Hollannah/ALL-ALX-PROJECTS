New to debugging
