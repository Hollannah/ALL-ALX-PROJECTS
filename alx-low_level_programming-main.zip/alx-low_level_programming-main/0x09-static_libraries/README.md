A library is not a luxury but one of the necessities of life
Without libraries what have we? We have no past and no future
1. Without libraries what have we? We have no past and no future
