0. Print list
1. List length
2. Add node2. Add node
3. Add node at the end
4. Free list
5. Free
6. Pop
7. Get node at index
8. Sum list
9. Insert
10. Delete at index
11. Reverse list
12. Print (safe version)
13. Free (safe version)
14. Find the loop
