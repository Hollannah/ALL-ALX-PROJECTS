Beauty is variable, ugliness is constant
To be is to be the value of a variable
One woman's constant is another woman's variable
To be is a to be the value of a variable
