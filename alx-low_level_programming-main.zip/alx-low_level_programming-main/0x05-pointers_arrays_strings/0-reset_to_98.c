#include "main.h"

/**
 * reset_to_98 - takes the pointer and updates the value
 *  @n: int to check
 *  Owned By Hollannah
 *  Return: 0 is success
 */

void reset_to_98(int *n)
{
		*n = 98;
}
