Pointers Arrays Strings
