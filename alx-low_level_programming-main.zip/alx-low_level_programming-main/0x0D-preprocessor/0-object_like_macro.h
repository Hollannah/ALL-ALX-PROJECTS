#ifndef _0_OBJECT_LIKE_MARCO_H_
#define _0_OBJECT_LIKE_MARCO_H_

#define SIZE 1024

#endif
