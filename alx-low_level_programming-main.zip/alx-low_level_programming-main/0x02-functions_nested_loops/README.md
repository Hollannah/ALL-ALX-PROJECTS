putchar
