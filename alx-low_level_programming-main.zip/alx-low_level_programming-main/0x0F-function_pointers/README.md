C - Function pointers
What's my name. If you spend too much time thinking about a thing, you'll never get it done
To hell with circumstances; I create opportunities
A goal is not always meant to be reached, it often serves simply as something to aim at\
Most hackers are young because young people tend to be adaptable. As long as you remain adaptable, you can always be a good hacker

