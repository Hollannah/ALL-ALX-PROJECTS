#!/usr/bin/python3
"""
Defines globally allowed modules in this package
"""
import models
