#!/usr/bin/python3
"""
Pass models import from api to be available for subpackages
"""
from .. import models
